devtools::install_github(
  repo = "Exp-Micro-Ecol-Hub/dmdScheme",
  ref = "master",
  force = TRUE,
  upgrade = "never"
)
